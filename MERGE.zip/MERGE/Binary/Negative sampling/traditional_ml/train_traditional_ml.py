import pandas as pd
import numpy as np
import os
from rdkit import Chem
from rdkit.Chem import AllChem
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, roc_auc_score, average_precision_score, f1_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib  # 用于保存模型
import argparse # 参数解析

# --------------------- 参数解析 ---------------------
parser = argparse.ArgumentParser(description='Train Traditional ML Models for DDI Prediction')
parser.add_argument('--data_dir', type=str, default='../', help='数据集目录路径')
parser.add_argument('--sampling_type', type=str, required=True, 
                    choices=['negative', 'randomized', 'categorical'], help='采样类型')
parser.add_argument('--feature_type', type=str, default='ecfp', 
                    choices=['ecfp', 'chemberta'], help='特征类型: ecfp 或 chemberta')
parser.add_argument('--model_type', type=str, required=True, 
                    choices=['lr', 'rf', 'svm'], help='模型类型: lr, rf, svm')
args = parser.parse_args()

# --------------------- 标签列和任务类型自动判断 ---------------------
if args.sampling_type in ['negative', 'randomized']:
    label_col = 'DDI'          # Binary 任务
    task_type = 'binary'
else:
    label_col = 'DDI_type'      # Multi-class 任务
    task_type = 'categorical'

# --------------------- 工具函数 ---------------------
def merge_smiles_pairs(df):
    """合并 SMILES 对为长序列（格式：drugA|drugB）"""
    df['merged_smiles'] = df['drug_A'] + '|' + df['drug_B']
    return df

def smiles_to_ecfp(smiles, radius=2, n_bits=1024):
    """生成 ECFP 指纹"""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return np.zeros(n_bits)
    return np.array(AllChem.GetMorganFingerprintAsBitVect(mol, radius, n_bits))

def generate_ecfp_features(df, feature_type='ecfp', n_bits=1024):
    """为整个数据集生成 ECFP 特征"""
    features = []
    for _, row in df.iterrows():
        smiles_a, smiles_b = row['merged_smiles'].split('|')
        if feature_type == 'ecfp':
            fp_a = smiles_to_ecfp(smiles_a)
            fp_b = smiles_to_ecfp(smiles_b)
            features.append(np.concatenate([fp_a, fp_b]))  # 合并两个药物的指纹
        elif feature_type == 'chemberta':
            features.append(np.random.rand(768 * 2))  # 假设嵌入维度为 768 
    return np.array(features)

# --------------------- 主流程 ---------------------
if __name__ == "__main__":
    # 1. 加载数据
    tr_df = pd.read_csv('../tr_dataset.csv')
    val_df = pd.read_csv('../val_dataset.csv')
    tst_df = pd.read_csv('../tst_dataset.csv')

    # 2. 合并 SMILES
    tr_df = merge_smiles_pairs(tr_df)
    val_df = merge_smiles_pairs(val_df)
    tst_df = merge_smiles_pairs(tst_df)

    # 3. 生成 ECFP 特征（耗时操作，可缓存）
    print("Generating ECFP features...")
    X_train = generate_ecfp_features(tr_df, n_bits=1024)
    X_val = generate_ecfp_features(val_df, n_bits=1024)
    X_test = generate_ecfp_features(tst_df, n_bits=1024)
    y_train = tr_df[args.label_col].values
    y_val = val_df[args.label_col].values
    y_test = tst_df[args.label_col].values
    if args.model_type == 'svm':  # 特征标准化（仅 SVM 需要）
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_val = scaler.transform(X_val)
        X_test = scaler.transform(X_test)

    # 4. 训练模型
    print(f"Training {args.model_type.upper()} Model...")
    if args.model_type == 'lr':
        model = LogisticRegression(max_iter=1000)
    elif args.model_type == 'rf':
        model = RandomForestClassifier(n_estimators=100)
    elif args.model_type == 'svm':
        model = SVC(probability=True) if task_type == 'binary' else SVC()
    model.fit(X_train, y_train)

    # 5. 评估
    if task_type == 'binary':
        y_proba = model.predict_proba(X_test)[:, 1]
        auroc = roc_auc_score(y_test, y_proba)
        aupr = average_precision_score(y_test, y_proba)
        print(f"AUROC: {auroc:.4f}, AUPR: {aupr:.4f}")
    else:
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        macro_f1 = f1_score(y_test, y_pred, average='macro')
        print(f"Accuracy: {acc:.4f}, Macro-F1: {macro_f1:.4f}")
        print(classification_report(y_test, y_pred))

    # 6. 保存模型
    output_dir = os.path.join(args.data_dir, 'traditional_ml', 'results', 
                             f"{args.sampling_type}_{args.feature_type}_{args.model_type}")
    os.makedirs(output_dir, exist_ok=True)
    joblib.dump(model, os.path.join(output_dir, 'model.pkl'))
    pd.DataFrame({'y_true': y_test, 'y_pred': y_pred if task_type == 'categorical' else y_proba}
                ).to_csv(os.path.join(output_dir, 'predictions.csv'), index=False)

if __name__ == "__main__":
    main()